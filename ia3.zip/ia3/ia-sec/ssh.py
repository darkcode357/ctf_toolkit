#!/usr/bin/env python

import sys, paramiko
def ssh():

    try:
        client = paramiko.SSHClient()
        client.load_system_host_keys()
        client.set_missing_host_key_policy(paramiko.WarningPolicy)

        client.connect("127.0.0.1", port=22, username="root", password="dsa")

        stdin, stdout, stderr = client.exec_command("ls")
        print (stdout.read(),)

    finally:
        client.close()
