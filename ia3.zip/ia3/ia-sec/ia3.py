#coding: utf-8
# -*- coding:utf-8 -*-
#!/usr/bin/python3
#criador darkcode
import pyttsx3  # importamos o modúlo
from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer
from os import system
import speech_recognition as sr  #reduz o modulo
import info
system("clear")
####################################
# modulos da ia
####################################
from main.infra.banner.banner import kernel_banner

#cores
cyanClaro = "\033[1;36m"
vermelho = '\033[31;1m'
verde = '\033[32;1m'
azul = '\033[34;1m'
normal = '\033[0;0m'
purpleClaro = '\033[1;35m'
amarelo = '\033[1;33m'
ciano = '\033[46m'
magenta = '\033[45m'
normal = '\033[0;0m'
###################
#variaveis
en = pyttsx3.init() #inicia da voz
###################
import itertools
import threading
import time
import sys
from os import system
import os
from gtts import gTTS
from subprocess import call

###################
def main():
	print(amarelo + "=" * 70 + normal)
	print(azul + """
 ______     __  __     ______     ______     __  __     __     __   __     ______     ______     ______
/\  ___\   /\ \_\ \   /\  ___\   /\  ___\   /\ \/ /    /\ \   /\ "-.\ \   /\  ___\   /\  __ \   /\  ___\
\ \ \____  \ \  __ \  \ \  __\   \ \ \____  \ \  _"-.  \ \ \  \ \ \-.  \  \ \ \__ \  \ \ \/\ \  \ \___  \
 \ \_____\  \ \_\ \_\  \ \_____\  \ \_____\  \ \_\ \_\  \ \_\  \ \_\\"\_\  \ \_____\  \ \_____\  \/\_____\
  \/_____/   \/_/\/_/   \/_____/   \/_____/   \/_/\/_/   \/_/   \/_/ \/_/   \/_____/   \/_____/   \/_____/
versao = 0.1
criador = darkcode
ano = 2017
    """ + normal)
	print(amarelo + "=" * 70 + normal)


done = False


# here is the animation
def animate():
	for c in itertools.cycle(['|', '/', '-', '\\']):
		if done:
			break
		sys.stdout.write(verde + '\rloading ' + normal + vermelho + c)
		sys.stdout.flush()
		time.sleep(0.1)
	# sys.stdout.write('\rDone!     ')


t = threading.Thread(target=animate)
t.start()

# long process here
time.sleep(5)  # altera
done = True
print('\n')
if os.name == 'nt':
	print("windows")
if os.name == 'posix':
	print("=>check:")
	print("==> " + verde + "linux[+]" + normal)
print("" + azul + "=>" + " check " + "<=")
print("" + azul + "=>" + " python " + "<=")
	##############################################################################################################
print("" + azul + "=>" + " chattboot " + "<=" + normal)
try:
	import chatterbot

	print("" + vermelho + "=>" + "biblioteca" + azul + "[chatterbot]" + normal + vermelho + "[ok]" + normal)
except ImportError:
		# print("\t\t"+vermelho+"=>" +"biblioteca "+azul+"[chatterbot]" +normal +vermelho+"nao instalada"+normal)
	print("" + vermelho + "=>" + "instalando a biblioteca " + azul + "[chatterbot]" + normal)
	system("pip2 install  chatterbot ")
	##############################################################################################################
print("" + azul + "=>" + " speech_recognition " + "<=" + normal)
try:
	import speech_recognition

	print("" + vermelho + "=>" + "biblioteca" + azul + "[speech_recognition]" + normal + vermelho + "[ok]" + normal)
except ImportError:
	print("" + vermelho + "=>" + "instalando a biblioteca " + azul + "[speech_recognition]" + normal)
	system("pip2 install SpeechRecognition")
main()


def main():
	bot = ChatBot("=>test")
	conv = ["consulta...","comando os..."]
	#print(conv)
	bot.set_trainer(ListTrainer)
	bot.train(conv)
	kernel_banner()
	en.say("seja bem vindo darkcode!! ")
	en.say("como posso ajudalo")
	info.sobre_min()
	en.runAndWait()
	while True:

	   rr = input("")
	   rec = sr.Recognizer()  # instanciamos o modúlo do reconhecedor

	   with sr.Microphone() as fala:  # reduz o modulo
	       frase = rec.listen(fala)
	   print("=>")
	   pergunta = rec.recognize_google(frase, language='pt')  # coloca em portugues
	   print(pergunta)
	    # pergunta = raw_input(vermelho+'==>: '+normal)


	   if pergunta == "comando":
	   		#print(vermelho+"#"*10)
	    	print(azul+"ativar segurança[+]\npara segurança[+]\nativar  paranóia[+]\ninfo segurança[+]\ninfo redes neurais[+]\n")
	    	#print(vermelho+"#"*10)

	   if pergunta == "sobre":  # chama a função ajuda
	   	   info.sobre()
	   if pergunta == "quem sou":  # chama a função ajuda
		   info.sobre_min()




	   if pergunta =="infowars":
	   		import pwd
	   		import getpass
	   		for i in pwd.getpwall():
	   			print(i)

	   ##modulo de seguranca
	   elif pergunta == "ativar segurança":  # chama a função chocolate
	       os.system("bash firewall-arch start")
	   elif pergunta == "para segurança":  # chama a função chocolate
	       os.system("bash firewall-arch stop")
	   elif pergunta == "ativar  paranóia":  # chama a função chocolate
	       os.system("bash firewall-arch panic ")
	   elif pergunta == "info segurança":  # chama a função chocolate
	       os.system("bash firewall-arch install")




	   ##informacoes
	   elif pergunta == "info redes neurais":  # chama a função brute force
	       info.info_rede_neuronais()
	   elif pergunta == "cnpj":  # chama a função consulta
	       print()
	   elif pergunta == "brute-all":
	       print()
	   elif pergunta == "saida":  # saida
	       print("saida")
	   else:
	       system("clear")
	       print(verde + "=" * 21 + normal)
	       print(        azul + "comando incorreto use\n" + normal + vermelho + "==> ajuda \n" + normal + azul + "para lista os comandos" + normal)
	       print(verde + "=" * 21 + normal)
	        #			sys.exit()
	        # print('bot:'+ str(resposta))
	        # system(pergunta)

main()
