# modulo install
# criador darkcode
# date 2017
from os import system


def main():
    list = open("dsadsa", "r+")
    list.readline()
    for i in list:
        system("pip2 install " + i)
    list.close()


main()
