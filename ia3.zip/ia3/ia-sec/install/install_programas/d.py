from os import system


def main():
    list = open("dsa", "r+")
    lista2 = open("a.txt", "r+")

    list.readline()
    lista2.readline()
    #   print(len(list))

    for i in list:
        print(len(str(i)))
        system("apt-get  install -y  " + i)
        system("dpkg --configure -a ")
        system(
            " apt-get purge python-mini-buildd openstack-dashboard  python-manila-ui  python-designate-dashboard  python-app-catalog-ui python-openstack-doc-tools openstack-dashboard -y")


main()
