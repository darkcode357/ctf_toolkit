def firewall():
    import subprocess
    import os, glob
    print("limpando regras do firewall existente...")
    os.system("bash firewall-arch stop")
    os.system("bash firewall-arch start")
