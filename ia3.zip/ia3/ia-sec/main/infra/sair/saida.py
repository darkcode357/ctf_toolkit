import sys
def saida():
	sys.exit()
