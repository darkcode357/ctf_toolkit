# cores
cyanClaro = "\033[1;36m"
vermelho = '\033[31;1m'
verde = '\033[32;1m'
azul = '\033[34;1m'
normal = '\033[0;0m'
purpleClaro = '\033[1;35m'
amarelo = '\033[1;33m'
ciano = '\033[46m'
magenta = '\033[45m'
normal = '\033[0;0m'


def python_version():
    import platform
    dsa = platform.python_version_tuple()[0]
    dsa2 = platform.python_version_tuple()[1]
    version = str(dsa) + "." + str(dsa2)
    if version == "2.7":
        print(vermelho + "=>" + amarelo + "check:" + verde + "py-Version  :" + azul + "=>" + verde + version + normal)
    elif version == "3.5":
        print(vermelho + "=>" + amarelo + "check:" + verde + "py-Version  :" + azul + "=>" + verde + version + normal)
    elif version == "3.6":
        print(vermelho + "=>" + amarelo + "check:" + verde + "py-Version  :" + azul + "=>" + verde + version + normal)
    else:
        print("falha")


def gcc_version():
    import platform
    dsa = platform.python_compiler()[4]
    dsa2 = platform.python_compiler()[5]
    dsa3 = platform.python_compiler()[6]
    dsa4 = platform.python_compiler()[7]
    dsa5 = platform.python_compiler()[8]
    version = str(dsa + dsa2 + dsa3 + dsa4 + dsa)
    print(vermelho + "=>" + amarelo + "check:" + verde + "gcc-Version :" + azul + "=>" + verde + version + normal)
