import getpass
import os
import shlex
import subprocess
import time

# cores
cyanClaro = "\033[1;36m"
vermelho = '\033[31;1m'
verde = '\033[32;1m'
azul = '\033[34;1m'
normal = '\033[0;0m'
purpleClaro = '\033[1;35m'
amarelo = '\033[1;33m'
ciano = '\033[46m'
magenta = '\033[45m'
normal = '\033[0;0m'
#####################
def check_programas():
    list_cmd = ['msfconsole', 'pip2', 'pip3', 'tor', 'iptables']
    for cmd in list_cmd:
        exist = subprocess.call('command -v ' + cmd + '>> /dev/null', shell=True)
        if exist == 0:
            time.sleep(0.2)
            print(
                vermelho + "=>" + amarelo + "check :" + verde + cmd + normal + azul + "=>" + vermelho + "[ok]" + normal)
        else:
            print("\t"+vermelho + "=>" + normal + "FALHAS :" + verde + cmd+normal+azul+"=>"+vermelho+"[ok]"+normal)
            print ("\t\t't=>["+cmd+":try install]")
            subprocess.call('sudo pacman -S ' + cmd, shell=True)

    def check_editor():
        PATH = '/ia3/ia-sec/main/infra/ia_editor'

        if os.path.isdir(PATH) and os.access(PATH, os.R_OK):
            print ("File exists and is readable")
        else:
            print ("Either file is missing or is not readable")
