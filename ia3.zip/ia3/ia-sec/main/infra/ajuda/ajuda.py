from  os import system
#colors
cyanClaro="\033[1;36m"
vermelho = '\033[31;1m'
verde = '\033[32;1m'
azul = '\033[34;1m'
normal = '\033[0;0m'
purpleClaro= '\033[1;35m'
amarelo= '\033[1;33m'
ciano='\033[46m'
magenta='\033[45m'
normal = '\033[0;0m'
#######################

def ajuda():
	system("clear")
	print(verde+"="*21+verde)#essa linha vai ficar verde
	print(vermelho+"=>help"+normal)
	print(vermelho+"=>os"+normal)
	print(vermelho+"=>dns"+normal)
	print(vermelho+"=>brute-all"+normal)
	print(verde+"="*21+verde)#essa linha vai ficar verde