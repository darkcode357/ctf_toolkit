cyanClaro = "\033[1;36m"
vermelho = '\033[31;1m'
verde = '\033[32;1m'
azul = '\033[34;1m'
normal = '\033[0;0m'
purpleClaro = '\033[1;35m'
amarelo = '\033[1;33m'
ciano = '\033[46m'
magenta = '\033[45m'
normal = '\033[0;0m'

import os


def check_editor():
    PATH = '/home/luiz/Desktop/ia3/ia-sec/main/infra/ia_editor'

    if os.path.isdir(PATH) and os.access(PATH, os.R_OK):
        print(
            vermelho + "=>" + normal + amarelo + "check :" + verde + "editor" + azul + "=>" + vermelho + "[ok]" + normal)
    else:
        print(vermelho + "=>" + normal + "editor        :" + vermelho + "[OFF]" + normal)
