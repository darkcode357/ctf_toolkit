# -*- coding: utf-8 -*-
import platform
import subprocess
import time

from main.hacker.defesa.firewall.firewall_bash import firewall
from main.infra.detectacao.check_programas import check_programas
from main.infra.detectacao.check_versions import gcc_version
from main.infra.detectacao.check_versions import python_version
from main.infra.ia_editor.check_editor import check_editor
from main.infra.network.mac import	get_mac
from main.infra.network.network import Internal
from main.infra.network.network import Local
# redes##########################################
from  main.infra.network.network import PublicIp

#################################################
#cores##########################################
cyanClaro = "\033[1;36m"
vermelho = '\033[31;1m'
verde = '\033[32;1m'
azul = '\033[34;1m'
normal = '\033[0;0m'
purpleClaro = '\033[1;35m'
amarelo = '\033[1;33m'
ciano = '\033[46m'
magenta = '\033[45m'
normal = '\033[0;0m'

##################################################
#variavel#########################################
#################################################
def kernel_banner():
    criador = "Darkcode0x00"
    versaoo = "0.0.0.0.3"  # Oct  6
    code_nome = "kabuzia"  # Oct  6
    #ipp
    ippublico = PublicIp()
    #variavel
    iplocal = Local()
    #iplocal
    ipinterno = Internal()
    #ipinterno
    system = platform.system()
    #informações do sistema
    nome = platform.node()
    #hostname
    release = platform.release()
    #versão da  plataforma
    versao = platform.version()
    #versao
    arquitetura = platform.machine()
    #arquitetura do sistema 
    processador = platform.machine()

    ######################################
    print(azul+"""  

MMMMMMMMMMMMMMMMMMMMM.                             MMMMMMMMMMMMMMMMMMMMM
 `MMMMMMMMMMMMMMMMMMMM           M\  /M           MMMMMMMMMMMMMMMMMMMM'
   `MMMMMMMMMMMMMMMMMMM          MMMMMM          MMMMMMMMMMMMMMMMMMM'  
     MMMMMMMMMMMMMMMMMMM-_______MMMMMMMM_______-MMMMMMMMMMMMMMMMMMM    
      MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM    
      MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM    
      MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM    
     .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM.    
    MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM  
                   `MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM'                
                          `MMMMMMMMMMMMMMMMMM'                      
                              `MMMMMMMMMM'                              
                                 MMMMMM :F_P:                          
                                  MMMM                                  
                                   MM


                                   """)
    print("""
=======================================================================
██╗ █████╗       ███████╗███████╗ ██████╗     ██╗    ██████╗ 
██║██╔══██╗      ██╔════╝██╔════╝██╔════╝    ███║   ██╔═████╗
██║███████║█████╗███████╗█████╗  ██║         ╚██║   ██║██╔██║
██║██╔══██║╚════╝╚════██║██╔══╝  ██║          ██║   ████╔╝██║
██║██║  ██║      ███████║███████╗╚██████╗     ██║██╗╚██████╔╝
╚═╝╚═╝  ╚═╝      ╚══════╝╚══════╝ ╚═════╝     ╚═╝╚═╝ ╚═════╝ 
=======================================================================	
 """+normal)
    print(vermelho + "=" * 71 + normal)
    
    print(vermelho + "=>" + amarelo + "criador       :" + verde + criador + normal)
    
    print(vermelho + "=>" + amarelo + "versao        :" + verde + "[%s]" % versaoo)
    
    print(vermelho + "=>" + amarelo + "codenome      :" + verde + "[%s]" % code_nome)
    
    #print(vermelho + "=>" + amarelo + "IP-P          :" + verde +  + normal)
    #ippublico()
    
    print(vermelho + "=>" + amarelo + "mac-W         :" + verde + get_mac() + normal)
    
    print(vermelho + "=>" + amarelo + "System        :" + verde + system + normal)
    
    print(vermelho + "=>" + amarelo + "Nome          :" + verde + nome + normal)
    
    print(vermelho + "=>" + amarelo + "Relese        :" + verde + release + normal)
    
    print(vermelho + "=>" + amarelo + "Verso         :" + verde + versao + normal)
    
    print(vermelho + "=>" + amarelo + "sistema       :" + verde + system + normal)
    
    print(vermelho + "=>" + amarelo + "processador   :" + verde + processador + normal)
    
    print(vermelho + "=" * 71 + normal)
    
    print(vermelho + "=>" + azul + "compiladores:" + vermelho + "<==>" + normal + amarelo + "[0.1]")
    
    print(vermelho + "=" * 71 + normal)
    
    gcc_version()
    
    python_version()
    
    print(vermelho + "=" * 71 + normal)
    
    print(vermelho + "=>" + azul + "config-ia:" + vermelho + "<==>" + normal + amarelo + "[0.1]")
    
    check_editor()
    
    print(vermelho + "=" * 71 + normal)
    
    print(vermelho + "=>" + azul + "programas:" + vermelho + "<==>" + normal + amarelo + "[0.1]")
    
    print(vermelho + "=" * 71 + normal)
    
    check_programas()
    #print(vermelho + "=>" + azul + "firewall-status:" + vermelho + "<==>" + normal + amarelo + "[0.1]" + verde)
    #firewall()
