import socket
import ipgetter

def PublicIp():
    IP = ipgetter.myip()
def Internal():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(("8.8.8.8", 80))
    dsa = str(s.getsockname()[0])

def Local():
    ip = socket.gethostbyname(socket.gethostname())

def proxy():
    print()
