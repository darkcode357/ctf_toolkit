from gtts import gTTS
from subprocess import call

def sobre():
	with open("crowinfo/txt/info_project.txt",encoding="utf-8") as fl:
		fl = fl.read()
	speak = gTTS(fl,lang='pt')
	speak.save("crowinfo/mp3/info_project.mp3")
	call(['mplayer','crowinfo/mp3/info_project.mp3'])
def info_rede_neuronais():
	with open("crowinfo/txt/info_rede_neuronais.txt",encoding="utf-8") as fl:
		fl = fl.read()
	speak = gTTS(fl,lang='pt')
	speak.save("crowinfo/mp3/info_rede_neuronais.mp3")
	call(['mplayer','crowinfo/mp3/info_rede_neuronais.mp3'])
def sobre_min():
	with open("crowinfo/txt/quem_sou.txt",encoding="utf-8") as fl:
		fl = fl.read()
	speak = gTTS(fl,lang='pt')
	speak.save("crowinfo/mp3/quem_sou.mp3")
	call(['mplayer','crowinfo/mp3/quem_sou.mp3'])
